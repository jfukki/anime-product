

<?php $__env->startSection('content'); ?>

<!-- search bar -->

<?php echo $__env->make('components.searchBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- search bar -->

<div class="container extra-padding-container ">
    <div class="row" >
       <div class="col"> <h1>Searched For "Death Note"</h1>  </div>
    </div>

</div>

 
<div class="container ">

<?php $__currentLoopData = $search; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $search): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div  class="row searched-item-row" >
        
               
                <div class="col-md-2 searched-item-image">
                        <a href="<?php echo e(route('animeDetail' , $search['mal_id'])); ?>"> <img src="<?php echo e($search['images']['jpg']['large_image_url']); ?>" alt=""> </a>
                </div>
                <div class="col-md-4 mt-3">
                     <a href="<?php echo e(route('animeDetail' , $search['mal_id'])); ?>" class="searched-item-title">  <?php echo e($search['titles'][0]['title']); ?> <br> </a>
                     <span class="searched-item-rating">Rating: <?php echo e($search['rating']); ?></span>
                </div>
                <div class="col-md-2 mt-3">
                  <span class="searched-item-score">Score: <?php echo e($search['score']); ?> <br>Popularity: <?php echo e($search['popularity']); ?> </span>
                </div>
                <div class="col-md-2 mt-3">
                   <span class="searched-item-type">Type:<br><?php echo e($search['type']); ?></span>
                </div>
                <div class="col-md-2 mt-3">
                   <span class="searched-item-status">Status:<br>  <?php echo e($search['status']); ?></span>
                </div>
 
         
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>

 
     

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\discover-anime\resources\views/search.blade.php ENDPATH**/ ?>