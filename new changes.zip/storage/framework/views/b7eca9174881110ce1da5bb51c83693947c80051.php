
<div class="container extra-padding-container d-none d-md-block">
    <div class="row heading-row-title">
        <div class="col-md-10">
            <h2>Upcoming Soon </h2>
            
        </div>
        <div class="col-md-2">

            <p class="view-all-text"><a href="<?php echo e(route('home')); ?>">View all</a></p>
            
        </div>
    </div>

</div>

<div class="container d-none d-md-block">

        <div class="row row-cols-4">   

        <?php $__currentLoopData = $upcomingSeason; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upcomingSeason): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <div class="col anime-grid-list d-none d-md-block">

            <a href="<?php echo e(route('animeDetail' , $upcomingSeason['mal_id'])); ?>">
            <img src="<?php echo e($upcomingSeason['images']['jpg']['large_image_url']); ?>"
             alt="" class="anime-grid-list-image">
            </a>

            <a href="" class="text-decor">
                <p class="anime-title-list-grid"><?php echo e($upcomingSeason['titles'][0]['title']); ?></p>
            </a>
            
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  
   
    </div>

    

    
</div><?php /**PATH C:\xampp\htdocs\laravel\discover-anime\resources\views/components/comingsoon.blade.php ENDPATH**/ ?>