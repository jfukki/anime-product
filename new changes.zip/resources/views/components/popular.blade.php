
<div class="container extra-padding-container">
    <div class="row heading-row-title">
        <div class="col-md-10">
            <h2>Popular this season</h2>
            
        </div>
        <div class="col-md-2">

            <p class="view-all-text"><a href="{{ route('home') }}">View all</a></p>
            
        </div>
    </div>
    

    <div class="row">   

        <div class="col-md-3 anime-grid-list">

            <a href="">
            <img src="https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx141391-Wued34kHqIov.png"
             alt="" class="anime-grid-list-image">
            </a>

            <a href="" class="text-decor">
                <p class="anime-title-list-grid">Chainsaw Man</p>
            </a>
            
        </div>
 
        <div class="col-md-3 anime-grid-list">

            <a href="" >
            <img src="https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx145545-DGl3LVvFlnHi.png"
             alt="" class="anime-grid-list-image">
            </a>

            <a href="" class="text-decor">
                <p class="anime-title-list-grid">SPY x FAMILY Cour 2</p>
            </a>
        </div>
 
        <div class="col-md-3 anime-grid-list">

            <a href="">
            <img src="https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx140439-qpBzXkvVqSx3.jpg"
             alt="" class="anime-grid-list-image">
            </a>
              <a href="" class="text-decor">
                <p class="anime-title-list-grid">Mob Psycho 100 III</p>
            </a>
        </div>
   
       
        <div class="col-md-3 anime-grid-list">

            <a href="">
            <img src="https://s4.anilist.co/file/anilistcdn/media/anime/cover/large/bx101922-PEn1CTc93blC.jpg"
             alt="" class="anime-grid-list-image">
            </a>
              <a href="" class="text-decor">
                <p class="anime-title-list-grid">My Hero Academia Season 6</p>
            </a>
        </div>

        
    </div>
</div>