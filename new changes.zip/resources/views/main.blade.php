@include('layouts.header')
@include('layouts.navbar')
 
@yield('content')

@include('layouts.footer')
@include('layouts.footerScript')


