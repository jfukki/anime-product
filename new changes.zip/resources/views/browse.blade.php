@extends('main')

@section('content')

<!-- search bar -->

@include('components.searchBar')

<!-- search bar -->

    <div class="container extra-padding-container">
        <div class="row">
            <div class="col-md-12">
                <h2>Propular Anime</h2>
            </div>

            <div class="col-md-12">
                <h2>Top Pick For You</h2>
            </div>

            <div class="col-md-12">
                <h2>Action Anime</h2>
            </div>

            <div class="col-md-12">
                <h2>Sc-fi Anime</h2>
            </div>

            <div class="col-md-12">
                <h2>If you like Attack on Titan</h2>
            </div>

            <div class="col-md-12">
                <h2>Drama Anime</h2>
            </div>


        </div>
    </div>

@endsection