@extends('main')

@section('content')

<div class="container extra-padding-container mt-5">
    <div class="row">
        <h2>Reviews</h2>
        <hr>
    </div>
</div>

@include('components.reviewList')

@endsection