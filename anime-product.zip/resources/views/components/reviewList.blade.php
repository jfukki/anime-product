<div class="container extra-padding-container">
    <div class="row ">

        <div class="col-md-4">

                <div class="card anime-review-list-card" style="width:20rem;">
                        <img src="https://wallpapercrafter.com/desktop/71586-anime-girl-anime-artist-artwork-digital-art-hd-4k-rain.jpg"
                        class="card-img-top" alt="..."  style="height:231px;">
                        <div class="card-body">
                            <h5 class="card-title "><a href="{{route('reviewDeail')}}" class="review-card-title">Review Title</a></h5>
                            <p class="card-text review-card-description">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
                        </div>
                        <ul class="list-group list-group-flush">
                            <li class="list-group-item">
                                <img src="https://mdbcdn.b-cdn.net/img/new/avatars/2.webp" 
                                class="rounded-circle" style="width: 40px;"
                                alt="Avatar" />
                                - <span class="review-card-username">anie123</span> </li>
                                
                            <li class="list-group-item">
                                
                            <span class="review-card-like-thumbsup">
                            <i class="fa fa-thumbs-up"></i> 56
                            </span>
                        
                            
                            <span class="review-card-like-thumbsdown">
                            <i class="fa fa-thumbs-down"></i> 7856
                            </span>
                        
                            </li>
                            
                        </ul>
                        
                </div>


        </div>

        
    </div>
</div>