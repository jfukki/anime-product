

<?php $__env->startSection('content'); ?>

<div class="container extra-padding-container mt-5">
    <div class="row">
        <h2>Reviews</h2>
        <hr>
    </div>
</div>

<?php echo $__env->make('components.reviewList', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\discover-anime\anime-product\resources\views/animeReviews.blade.php ENDPATH**/ ?>