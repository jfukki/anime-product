
<div class="container extra-padding-container py-5 ">
    <div class="row ">
        <div class="col-md-3">
                <div class="mb-3  ">
                    <label  class="form-label searchbar-label">Search</label>
                   <form action="<?php echo e(route('search')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                     
                    <input type="text" class="form-control" id="searchAnimeTitle" name="searchAnimeTitle"  placeholder="Search By Title">
                    
                   </form>
                </div>
                                
                <!-- <button type="submit" class="btn btn-primary">Submit</button> -->
            </form>
        </div>
    </div>
</div>

<?php /**PATH C:\xampp\htdocs\Laravel\discover-anime\anime-product\resources\views/components/searchBar.blade.php ENDPATH**/ ?>