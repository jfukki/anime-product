

<?php $__env->startSection('content'); ?>

<!-- search bar -->

<?php echo $__env->make('components.searchBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- search bar -->

     <?php echo $__env->make('components.trending', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container " >
        <hr>
    </div>

     <?php echo $__env->make('components.comingsoon', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


     <div class="container mt-5 d-none d-md-block" >
        <hr>
    </div>
 
    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\discover-anime\anime-product\resources\views/home.blade.php ENDPATH**/ ?>