

<?php $__env->startSection('content'); ?>

<!-- search bar -->

<?php echo $__env->make('components.searchBar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- search bar -->

    <div class="container extra-padding-container">
        <div class="row">
           <?php echo $__env->make('components.popularAnime', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

           <div class="row " style="margin-top:10%;">
                <hr>
           </div>

           <?php echo $__env->make('components.movies', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           
           <div class="row " style="margin-top:10%;">
                <hr>
           </div>
           
           <?php echo $__env->make('components.airing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
           
           <div class="row " style="margin-top:10%;">
                
           </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\discover-anime\anime-product\resources\views/browse.blade.php ENDPATH**/ ?>