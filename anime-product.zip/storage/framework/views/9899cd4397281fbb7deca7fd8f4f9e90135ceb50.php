

<?php $__env->startSection('content'); ?>

<div class="container">
    
 
 <div class="row heading-row-title">
        <div class="col-md-10">
            
           <h2><b><?php echo e($anime); ?></b> Images</h2> 
            
        </div>
       
    </div>

<!-- Large Devices -->


<div class="row row-cols-5">   

    
<?php $__currentLoopData = $randomAnime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
 <?php if(isset($d)): ?>
    <div class="col anime-grid-list d-none d-md-block">

        <a  >
        <img src="<?php echo e($d['jpg']['large_image_url']); ?>"
        alt="" class="anime-grid-list-image">
        </a>
        
        
    </div>
    <?php else: ?>
    <h2>Please Reload Again!</h2>
    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- Large Devices -->



<!-- Mobile Devices -->


<div class="row row-cols-2">   

    
<?php $__currentLoopData = $randomAnime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col anime-grid-list d-md-none ">

        <a  >
            <img src="<?php echo e($d['jpg']['large_image_url']); ?>"
            alt="" class="anime-grid-list-image">
        </a>
        
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- Mobile Devices -->

 



</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\discover-anime\anime-product\resources\views/randomPictures.blade.php ENDPATH**/ ?>