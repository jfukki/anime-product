

<?php $__env->startSection('content'); ?>

<div class="container mt-5 extra-padding-container">
    <div class="row row-col-3">
        <div class="col">
            <div class="card-counter primary site-stats-card">
                <i class="fa fa-search  site-stats-icon"></i>
                <span class="count-name site-stats-title">Total Anime Searches |</span>
                <span class="count-numbers site-stats-counter"><?php echo e($count); ?></span>
            </div>
        </div>

        
        <div class="col">
            <div class="card-counter primary site-stats-card">
                <i class="fa fa-search  site-stats-icon"></i>
                <span class="count-name site-stats-title">Total Reviews |</span>
                <span class="count-numbers site-stats-counter">0</span>
            </div>
        </div>

        <div class="col">
            <div class="card-counter primary site-stats-card">
                <i class="fa fa-search  site-stats-icon"></i>
                <span class="count-name site-stats-title">Total Anime |</span>
                <span class="count-numbers site-stats-counter"><?php echo e($anime_count); ?></span>
            </div>
        </div>

        
        
    </div>
</div>




<?php $__env->stopSection(); ?>
<?php echo $__env->make('main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\discover-anime\anime-product\resources\views/site_stats.blade.php ENDPATH**/ ?>