

    <div class="row heading-row-title">
        <div class="col-md-10">
            <h2>Airing Anime</h2>
            
        </div>
        <div class="col-md-2">

            <p class="view-all-text"><a href="<?php echo e(route('home')); ?>">View all</a></p>
            
        </div>
    </div>

<!-- Large Devices -->


<div class="row row-cols-5">   

    
<?php $__currentLoopData = $airing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(isset($airing)): ?>    

    <div class="col anime-grid-list d-none d-md-block mt-5">

        <a href="<?php echo e(route('animeDetail' , $d['mal_id'])); ?>">
        <img src="<?php echo e($d['images']['jpg']['large_image_url']); ?>"
        alt="" class="anime-grid-list-image">
        </a>
        <a href="<?php echo e(route('animeDetail' , $d['mal_id'])); ?>" class="text-decor">
            <p class="anime-title-list-grid"><?php echo e($d['title']); ?></p>
        </a>
        
    </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- Large Devices -->



<!-- Mobile Devices -->


<div class="row row-cols-2">   

    
<?php $__currentLoopData = $airing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php if(isset($airing)): ?>    

    <div class="col anime-grid-list d-md-none ">

        <a href="<?php echo e(route('animeDetail' , $d['mal_id'])); ?>">
        <img src="<?php echo e($d['images']['jpg']['large_image_url']); ?>"
        alt="" class="anime-grid-list-image">
        </a>
        <a href="<?php echo e(route('animeDetail' , $d['mal_id'])); ?>" class="text-decor">
            <p class="anime-title-list-grid"><?php echo e($d['title']); ?></p>
        </a>
        
    </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<!-- Mobile Devices -->

 <?php /**PATH C:\xampp\htdocs\Laravel\discover-anime\anime-product\resources\views/components/airing.blade.php ENDPATH**/ ?>