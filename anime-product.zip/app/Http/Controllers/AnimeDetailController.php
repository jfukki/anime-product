<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AnimeDetailController extends Controller
{
    //
}
